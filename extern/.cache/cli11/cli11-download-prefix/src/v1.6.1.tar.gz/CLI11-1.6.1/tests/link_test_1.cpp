#include "CLI/CLI.hpp"
#include "CLI/Timer.hpp"

int do_nothing() { return 7; }
